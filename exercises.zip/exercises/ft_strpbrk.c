char	*ft_strpbrk(const char *s1, const char *s2)
{
	if (!*s1 || !*s2)
		return (0);
	while (*s1)
	{
		int i = 0;
		while (*s2)
		{
			if (*s1 == s2[i])
				return ((char *)s1);
			i++;
		}
		s1++;
	}
	return ((void *)0);
}

#include <stdio.h>
#include <string.h>

int main() {
    const char *s = "hello, world!";
    const char *accept = "aiu";  // Набор символов

    // Поиск первого совпадения любого из символов из строки accept
    char *result = strpbrk(s, accept);

    if (result != NULL) {
        printf("Первый совпадающий символ: '%c'\n", *result);
    } else {
        printf("Совпадающих символов не найдено.\n");
    }

    return 0;
}
