#include <unistd.h>

void	print_b(unsigned char c)
{
	int i = 8;
	unsigned char	result = 0;

	while (i--)
	{
		res = (c >> i & 1) + '0';
		write(1, &res, 1);
	}

}