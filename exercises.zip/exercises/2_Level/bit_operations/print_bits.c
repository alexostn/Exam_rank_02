#include <unistd.h>

void print_bits(unsigned char octet)
{
	int	i = 8;
	unsigned char	bit;

	while (i--)
	{
		bit = (octet >> i & 1) + '0';
		write(1, &bit, 1); 
	}
}

// #include <stdio.h>
// #include <stdlib.h>

// int main(int argc, char **argv)
// {
//     if (argc != 2)
//     {
//         printf("Usage: %s <number>\n", argv[0]);
//         return 1;
//     }

//     unsigned char octet = (unsigned char)atoi(argv[1]);
//     print_bits(octet);

//     return 0;
// }

// #include <stdio.h>
// #include <stdlib.h>

// int	main(int ac, char*av[])
// {
// 	if (ac != 2)
// 		printf("write number");
// 	else
// 	{
// 	unsigned char octet = (unsigned char)atoi(av[1]);
// 	print_bits(octet);
// 	return(0);
// 	}
// }

int	main()
{
	unsigned char	octet = 8;
	print_bits(octet);
}