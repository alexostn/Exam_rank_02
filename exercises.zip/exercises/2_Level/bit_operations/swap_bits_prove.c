#include <stdio.h>

unsigned char	swap_bits(unsigned char octet)
{
	return (octet >> 4 | octet << 4);
}

// void	print_bits(unsigned char octet)
// {
// 	int	i = 7;
// 	while (i >= 4)
// 	{
// 		printf("%d", (octet >> i) & 1);
// 		i--;
// 	}
// 	printf(" | ");
// 	while (i >= 0)
// 	{
// 		printf("%d", (octet >>i) & 1);
// 		i--;
// 	}
// 	printf("\n");
// }


// int main()
// {
// 	unsigned char	octet = 65;
// 	printf("1 byte\n");
// 	printf("____________\n");
// 	print_bits(octet);
// 	printf("    \\ /\n");
// 	printf("    / \\\n");
// 	print_bits(swap_bits(octet));
// 	printf("\n");
// 	return (0);
// }