int	    is_power_of_2(unsigned int n)
{
	if (n == 0)
		return(0);
	return (n &(n - 1)) == 0;
}

// #include <stdio.h>
// #include <stdlib.h>

// int main(int ac, char **av)
// {
// 	// Проверяем, что передан ровно один аргумент (кроме имени программы)
// 	if (ac == 2)
// 	{
// 		// Преобразуем строку в целое число
// 		unsigned int num = (unsigned int)atoi(av[1]);

// 		// Проверяем, является ли число степенью двойки
// 		if (is_power_of_2(num))
// 			printf("%u is a power of 2\n", num);
// 		else
// 			printf("%u is not a power of 2\n", num);
// 	}
// 	else
// 	{
// 		// Если неверное количество аргументов, выводим сообщение об ошибке
// 		printf("Usage: %s <number>\n", av[0]);
// 	}
// 	return 0;
// }