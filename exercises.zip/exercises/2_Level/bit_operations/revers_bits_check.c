// #include <unistd.h>
// #include <stdio.h>
// #include <stdlib.h>

unsigned char	revers_bits(unsigned char octet)
{
	int	i = 8;
	unsigned char	rev = 0;

	while (i > 0)
	{
	rev = rev * 2 + (octet % 2);
	octet = octet / 2;
	i--;
	}
	return (rev);
}

// void	print_b(unsigned char c)
// {
// 	int j = 8;
// 	unsigned char	res = 0;

// 	while (j--)
// 	{
// 		res = (c >> j & 1) + '0';
// 		write(1, &res, 1);
// 	}

// }

// int	main(int ac, char **av)
// {
// 	if (ac == 2)
// 	{
// 	unsigned char octet = (unsigned char)atoi(av[1]);
// 	unsigned char reversed = revers_bits(octet);

// 	print_b(octet);
// 	printf("_____________\n");
// 	print_b(reversed);
// 	printf("initial:%d\n", octet);
// 	printf("reversed:%d\n", reversed);
// 	}
// }
