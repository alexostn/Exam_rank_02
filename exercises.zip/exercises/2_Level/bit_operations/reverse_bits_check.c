unsigned char	reverse_bits(unsigned char octet)
{
	unsigned char res = 0;
	int	i = 8;
	
	while (i > 0)
	{
		res = res * 2 + (octet % 2);
		octet = octet / 2;
		i--;
	}
	return (res);
}

#include <stdio.h>
#include <stdlib.h>

int main(int ac, char *av[])
{
	if (ac == 2)
	{
	unsigned char octet = (unsigned char)atoi(av[1]);
	unsigned char reversed = reverse_bits(octet);
	printf("initial number: %d", octet);
	printf("reversed number: %d", reversed);
	}
	return (0);
}