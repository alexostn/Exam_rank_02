unsigned char	swap_bits(unsigned char octet)
{
	return (octet >> 4 | octet << 4);
}

// #include <stdio.h>
// #include <stdlib.h>
// int main (int ac, char **av)
// {
// 	if (ac == 2)
// 	{
// 		unsigned char octet = (unsigned char)atoi(av[1]);
// 		printf("%u", swap_bits(octet));
// 	}
// 	return (0);
// }