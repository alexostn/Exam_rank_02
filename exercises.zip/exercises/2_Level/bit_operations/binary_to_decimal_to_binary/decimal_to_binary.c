#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Функция для преобразования числа в двоичное представление
void decimal_to_binary(int number)
{
    // Определяем количество бит в типе int
    int bits = sizeof(int) * 8; // Обычно 32 бита для int

    // Печатаем биты начиная с самого старшего
    for (int i = bits - 1; i >= 0; i--)
    {
        int bit = (number >> i) & 1;
        printf("%d", bit);
    }
    printf("\n");
}

int main(int ac, char *av[])
{
    if (ac == 2)
    {
        int num = atoi(av[1]);

        // Вызываем функцию для преобразования числа в двоичное представление
        decimal_to_binary(num);
    }
    return 0;
}
