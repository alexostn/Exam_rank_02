#include <stdio.h>
#include <string.h>

int binary_to_decimal(const char *binary)
{
	int decimal = 0;
	int length = strlen(binary);
	int base = 1; // Initial power of two (2^0)
	int i = length - 1; // Start from the last character of the string

	// Using a while loop instead of for
	while (i >= 0) 
	{
		if (binary[i] == '1') 
		{
			decimal = decimal + base; // Add the value of the current power of two if the bit is 1
		}
		base = base * 2; // Increase the power of two (multiply by 2)
		i--; // Move to the next bit (to the left)
	}

	return decimal;
}

int main() 
{
	char binary[100];

	// Input binary number
	printf("Enter a binary number: ");
	scanf("%s", binary);

	// Convert binary number to decimal
	int decimal = binary_to_decimal(binary);

	// Output the result
	printf("Decimal number: %d\n", decimal);

	return 0;
}
