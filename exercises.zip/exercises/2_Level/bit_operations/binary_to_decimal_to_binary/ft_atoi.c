#include <stdio.h>
#include <stdlib.h>

// int ft_atoi(char *s)
// {
// 	int	i = 0;
// 	int	sign = 1;

// 	while ((*s >= 9 && *s <= 13) || *s == 32)
// 		s++;
// 	if (*s == '-')
// 		sign = -1;
// 	if (*s == '-' || *s == '+')
// 		s++;
// 	while (*s >= '0' && *s <= '9')
// 	{
// 		i = i * 10 + *s - '0';
// 		s++;
// 	}
// 	return (i * sign);
// }

int	ft_atoi(char *s)
{
	int i = 0;
	int sign = 1;

	while (*s == 32 || (*s >= 9 && *s <= 13))
		s++;
	if (*s == '-')
		sign = -1;
	if (*s == '+' || *s == '-')
		s++;
	while (*s >= '0' && *s <= '9')
		i = i * 10 + *s++ - '0';
	return (i * sign);
}

// int	main(int ac, char *av[])
// {
// 	if (ac == 2)
// 	{
// 		printf("%d\n", ft_atoi(av[1]));
// 		printf("%d\n", atoi(av[1]));
// 	}
// 	return (0);
// }
void test_ft_atoi(char *str)
{
    int ft_result = ft_atoi(str);
    int result = atoi(str);

    if (ft_result != result)
    {
        printf("Test failed for input '%s': ft_atoi returned %d, but atoi returned %d\n", str, ft_result, result);
    }
    else
    {
        printf("Test passed for input '%s': both ft_atoi and atoi returned %d\n", str, ft_result);
    }
}

int main()
{
    test_ft_atoi("123");
    test_ft_atoi("-123");
    test_ft_atoi("   123");
    test_ft_atoi("   -123");
    test_ft_atoi("123abc");
    test_ft_atoi("-123abc");
    test_ft_atoi("   123abc");
    test_ft_atoi("   -123abc");
    test_ft_atoi("abc123");
    test_ft_atoi("abc-123");
    test_ft_atoi("   abc123");
    test_ft_atoi("   abc-123");

    return 0;
}