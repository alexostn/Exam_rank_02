// #include <unistd.h>
// #include <stdio.h>
// #include <limits.h>
// #include <stdlib.h>

int	ft_atoi(const char *str)
{
	int	sign = 1;
	int	result = 0;
	// int i = 0;

	while (*str == 32 || (*str >= 9 && *str <= 13))
		str++;
	if (*str == '-')
		sign = -1;
	if (*str == '-' || *str == '+')
		str++;
	while ((*str >= '0' && *str <= '9'))
	{
// if (result > INT_MAX / 10 || ((result == INT_MAX / 10 && (*str - '0' > 7) && sign == 1) || (result == INT_MAX / 10 && (*str - '0' > 8) && sign == -1)))
// {
//     if (sign == 1)
//         return INT_MAX;
//     else
//         return INT_MIN;
// }
		result = result * 10 + *str++ -48;
	}
	// if (sign * result) > MAX_INT || 
	return (sign * result);
}

// int	main(void)
// {
//     char str[50];

//     sprintf(str, "%d", INT_MAX); // конвертируем INT_MAX в строку
//     printf("atoi(INT_MAX) = %d, ft_atoi(INT_MAX) = %d\n", atoi(str), ft_atoi(str));


//     sprintf(str, "%ld", LONG_MAX); // конвертируем LONG_MAX в строку
//     printf("atoi(LONG_MAX) = %d, ft_atoi(LONG_MAX) = %d\n", atoi(str), ft_atoi(str));

//     sprintf(str, "%d", INT_MIN); // конвертируем INT_MIN в строку
//     printf("atoi(INT_MIN) = %d, ft_atoi(INT_MIN) = %d\n", atoi(str), ft_atoi(str));

// 	sprintf(str, "%ld", LONG_MIN); // конвертируем LONG_MIN в строку
//     printf("atoi(LONG_MIN) = %d, ft_atoi(LONG_MIN) = %d\n", atoi(str), ft_atoi(str));
//     return (0);
// }