#include <unistd.h>

void	main(int ac, char **av)
{
	int	i = 0;
	if (ac == 2 && av[1][i] != 0)
	{
		while (av[1][i] == ' ')
			i++;
		while (av[1][i] != 0)
		{
			if (av[1][i] == ' ' && av[1][i + 1] == ' ')
			{
				while (av[1][i] == ' ')
					i++;
			write (1, " ", 1);
			}
			else
			{
				write (1, &av[1][i], 1);
				i++;
			}
		}
	}
	else
		write (1, "\n", 1);
}
