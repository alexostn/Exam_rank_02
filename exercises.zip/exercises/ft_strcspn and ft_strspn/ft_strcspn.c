#include <stdio.h>
#include <stdlib.h>
#include <string.h>

size_t	ft_strcspn(const char *s, const char *reject)
{
	size_t	i = 0;
	size_t j = 0;

	while (s[i] != '\0')
	{
		j = 0;
		while (reject[j] != '\0')
		{
			if (s[i] == reject[j])
				return(i);
			j++;
		}
		i++;
	}
	return (i);
}


int main()
{
	char *s = "AlexOst";
	char *reject = "s";
	// size_t	length = strcspn(s, reject);

	// printf("allowed symbols at the beginning of the string: %zu\n", length);

	// size_t	length = strcspn(s, reject);

	printf("allowed symbols at the beginning of the string: %zu\n", ft_strcspn(s, reject));
	printf("allowed symbols at the beginning of the string: %zu\n", strcspn(s, reject));

	
	return (0);
}
