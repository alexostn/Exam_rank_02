#include <unistd.h>

size_t	ft_strlen(const char *s)
{
	size_t l = 0;
	
	while (*s)
	{
		l++;
		s++;
	}
	return (l);
}

int main (int ac, char *av[])
{
	void	replace(char *str)
	{
		while (*str != '\0')
		{
			char	i;
			char	j;
			char	q;

			if (str[i] == av[2][j])
			{
				write (1, &av[3][j],1);
				str++;
			}
			else
				write(1, str++, 1);
		}
	}
	if (ac == 4 && ft_strlen(av[2]) == 1 && ft_strlen(av[3]) == 1)
	{
		replace(av[1]);
	}
	write(1, "\n", 1);
}
