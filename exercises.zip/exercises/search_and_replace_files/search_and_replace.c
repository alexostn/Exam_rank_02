#include <unistd.h>

size_t	ft_strlen(const char *s)
{
	size_t l = 0;
	
	while (*s)
	{
		l++;
		s++;
	}
	return (l);
}
	void	replace(char *str, char *av2, char *av3)
	{
		while (*str != '\0')
		{
			if (*str == *av2)
			{
				write (1, av3, 1);
				str++;
			}
			else
				write(1, str++, 1);
		}
	}

int main (int ac, char *av[])
{
	if (ac == 4 && ft_strlen(av[2]) == 1 && ft_strlen(av[3]) == 1)
	{
		replace(av[1], av[2], av[3]);
	}
	write(1, "\n", 1);
}
