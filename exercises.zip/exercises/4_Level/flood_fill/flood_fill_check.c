typedef struct s_point
{
	int	x;
	int	y;
}	t_point

void	fill(char ** arr, t_point size, t_point cur, char *to_fill)
{
	if (cur.x < 0 || cur.y <0 || cur.x >= size.x || cur.y >= size.y || tab[cur.x][cur.y] != to_fill)
		return;
	arr(cur.x, cur.y) = 'F';
	fill(arr, size, (t_point){cur.x - 1, cur.y}, to_fill);
	fill(arr, size, (t_point){cur.x + 1, cur.y}, to_fill);
	fill(arr, size, (t_point){cur.x, cur.y -1}, to_fill);
	fill(arr, size, (t_point){cur.x, cur.y +1}, to_fill);
}

to_fill(char **arr, t_point size, t_point begin)
{
	fill(arr, size, begin, arr[begin.y][begin.x]);
}
