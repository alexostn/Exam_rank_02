// Definition of the t_point structure, representing a point with x and y coordinates
#include "flood_fill.t_point.h"
// what is written UP is to to exclude those DOWN:
// typedef struct s_point
// {
// 	int x; // x coordinate
// 	int y; // y coordinate
// } t_point;

// Recursive function that fills an area on a 2D character map
// tab: 2D array of characters
// size: map size (width and height)
// cur: current position from which the filling starts
// to_fill: character that needs to be replaced
void fill(char **tab, t_point size, t_point cur, char to_fill)
{
	// Boundary and exit condition checks
	// If the current position is out of bounds or already filled, exit the function
	if (cur.y < 0 || cur.y >= size.y || cur.x < 0 || cur.x >= size.x || tab[cur.y][cur.x] != to_fill)
		return;
	
	// Replace the current character with 'F'
	tab[cur.y][cur.x] = 'F';
	
	// Recursive calls for all four directions (left, right, up, down)
	fill(tab, size, (t_point){cur.x - 1, cur.y}, to_fill); // Left
	fill(tab, size, (t_point){cur.x + 1, cur.y}, to_fill); // Right
	fill(tab, size, (t_point){cur.x, cur.y - 1}, to_fill); // Up
	fill(tab, size, (t_point){cur.x, cur.y + 1}, to_fill); // Down
}

// Function to initiate the fill process
// tab: 2D array of characters
// size: map size (width and height)
// begin: starting position from which filling begins
void flood_fill(char **tab, t_point size, t_point begin)
{
	// Start the recursive fill, passing the initial character to replace
	fill(tab, size, begin, tab[begin.y][begin.x]);
}
