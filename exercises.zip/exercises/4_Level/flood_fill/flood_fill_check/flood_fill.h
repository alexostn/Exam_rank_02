#ifndef DOES_NOT_MATTER_THE_NAME
# define DOES_NOT_MATTER_THE_NAME

  typedef struct  s_point
  {
    int           x;
    int           y;
  }               t_point;

void  flood_fill(char **tab, t_point size, t_point begin);

#endif