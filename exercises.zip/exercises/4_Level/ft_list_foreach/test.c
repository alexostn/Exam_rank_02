#include <stdio.h>
#include "ft_list.h"
// Функция, которая будет передана как аргумент для ft_list_foreach
// Она принимает указатель на данные (в данном случае строку) и выводит её
void	print_data(void *data)
{
	printf("%s\n", (char *)data);
	// Приводим указатель к типу char * (так как мы знаем, что это строка)
}

int	main(void)
{
	// Создаем три узла списка с данными и связями между ними
	// Последний узел указывает на NULL, так как он конечный элемент
	t_list node4 = {NULL, "Node 4"};
	t_list node3 = {&node4, "Node 3"};
	t_list node2 = {&node3, "What?"};
	t_list node1 = {&node2, "Node 1"};
	// Передаем первый узел списка (node1) и функцию print_data
	// Функция ft_list_foreach применит print_data к каждому узлу
	ft_list_foreach(&node1, print_data);
	return (0);
}
