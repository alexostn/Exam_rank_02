#include <unistd.h>

void	putnbr(int n)
{
	int	i;

	if (n >= 10)
		putnbr(n / 10);
	i = n % 10 + '0';
	write (1, &i, 1);
}

int	main(int ac, char *av[])
{
	if (ac > 1)
		putnbr(ac -1);
	else
		write(1, "0", 1);
	// write(1, "\n", 1);
	return (0);
}
