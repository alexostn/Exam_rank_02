#include <unistd.h>
#include <stdlib.h>

void	putnum(int n)
{
	char	c;

	if (n < 0)
	{
		write (1, "-", 1);
		n = -n;
	}
	if (n >= 10)
		putnum(n / 10);
	c = (n % 10) + '0';
	write (1, &c, 1);
}

int	main(int ac, char **av)
{
	if (ac == 2)
	{
	putnum(atoi(av[1]));
	return (0);
	}
}