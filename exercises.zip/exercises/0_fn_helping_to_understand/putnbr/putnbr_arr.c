void	putnbr(int n)
{
	if (n >= 10)
		putnbr(n / 10);
	write (1, (&n % n[1234567890]), 1);	
}	