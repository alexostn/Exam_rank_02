#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    int base; // База для преобразования числа
    char *endptr, *str; // Указатели на строку и конец преобразованной части строки
    long val; // Значение, полученное после преобразования строки

    // Если аргументы командной строки не предоставлены, выводится сообщение об ошибке
    if (argc < 2) {
        fprintf(stderr, "Usage: %s str [base]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    str = argv[1]; // Строка для преобразования
    base = (argc > 2) ? atoi(argv[2]) : 0; // База для преобразования, если предоставлена, иначе 0

    errno = 0; // Сброс errno перед вызовом strtol

    // Преобразование строки в число с использованием strtol
    val = strtol(str, &endptr, base);

    // Проверка на наличие ошибок после вызова strtol
    if (errno != 0) {
        perror("strtol");
        exit(EXIT_FAILURE);
    }

    // Если endptr равен str, значит, в строке не было найдено чисел
    if (endptr == str) {
        fprintf(stderr, "No digits were found\n");
        exit(EXIT_FAILURE);
    }

    // Если мы здесь, значит, strtol успешно преобразовал число
    printf("strtol() returned %ld\n", val);

    // Если после числа в строке есть еще символы, это не обязательно ошибка
    if (*endptr != '\0')
        printf("Further characters after number: \"%s\"\n", endptr);

    exit(EXIT_SUCCESS); // Успешное завершение программы
}