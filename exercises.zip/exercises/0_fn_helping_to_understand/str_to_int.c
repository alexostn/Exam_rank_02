#include <stdio.h>
#include <stdlib.h>


int str_to_int(char *str)
{
	int result = 0;
	while (*str != '\0')
	{
		result = result * 10 + (*str - '0');
		str++;
	}
	return result;
}

int main(int argc, char *argv[])
{
	if (argc == 2)
	{
	if (*argv[1] >= '0' && *argv[1] <= '9')
	{
	printf("result: %d\n" , str_to_int(argv[1]));
	}
	}
}