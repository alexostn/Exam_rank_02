#include <stdlib.h>

void	allocate_and_free(int N, int M)
{
int	**A;

A = (int**) malloc(N * sizeof(int*));
if (A == NULL)
	return; //handle error

for (int i = 0; i < N; ++i)
{
	A[i] = (int*) malloc(M * sizeof(int));
	if (A[i] == NULL)
		return; //handle error
}
// Use the array. . .

for (int i = 0; i < N; i++) free(A[i]);
free(A);
}

int	main()
	{
		allocate_and_free(10, 10);
		return (0);
	}
