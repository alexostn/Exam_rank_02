#include <stdio.h>

#define ROWS 3
#define COLS 7

int main()
{
	int arr[ROWS][COLS] = {
		{1, 2, 3, 4, 5, 6, 7},
		{8, 9, 10, 11, 12, 13, 14},
		{15, 16, 17, 18, 19, 20, 21}
	};

	int *ptr = &arr[0][0];
	int i, j;

	// Вывод массива построчно (вперед)
	printf("Array forward:\n");
	i = 0;
	while(i < ROWS)
	{
		j = 0;
		while(j < COLS)
		{
			printf("%2d ", arr[i][j]);
			j++;
		}
		printf("\n");
		i++;
	}

	// Вывод массива построчно (назад)
	printf("\nArray backward:\n");
	i = ROWS - 1;
	while(i >= 0)
	{
		j = COLS - 1;
		while(j >= 0)
		{
			printf("%2d ", arr[i][j]);
			j--;
		}
		printf("\n");
		i--;
	}

	// Прямой доступ к памяти (вперед)
	printf("\nDirect memory access forward:\n");
	i = 0;
	while(i < ROWS * COLS)
	{
		printf("%2d ", *(ptr + i));
		i++;
	}
	printf("\n");

	// Прямой доступ к памяти (назад)
	printf("\nDirect memory access backward:\n");
	i = ROWS * COLS - 1;
	while(i >= 0)
	{
		printf("%2d ", *(ptr + i));
		i--;
	}
	printf("\n");

	return 0;
}
