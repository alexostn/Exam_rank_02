#include <stdio.h>
#include <stdlib.h>

#define ROWS 3
#define COLS 7

// Рекурсивные функции для заполнения массива
void fillArray(int **arr, int row, int col, int value)
{
	if (row >= ROWS) return;
	if (col >= COLS)
	{
		fillArray(arr, row + 1, 0, value);
		return;
	}
	arr[row][col] = value;
	fillArray(arr, row, col + 1, value + 1);
}

// Рекурсивные функции для вывода массива
void printArrayForward(int **arr, int row, int col)
{
	if (row >= ROWS) return;
	if (col >= COLS)
	{
		printf("\n");
		printArrayForward(arr, row + 1, 0);
		return;
	}
	printf("%2d ", arr[row][col]);
	printArrayForward(arr, row, col + 1);
}

void printArrayBackward(int **arr, int row, int col)
{
	if (row < 0) return;
	if (col < 0)
	{
		printf("\n");
		printArrayBackward(arr, row - 1, COLS - 1);
		return;
	}
	printf("%2d ", arr[row][col]);
	printArrayBackward(arr, row, col - 1);
}

void printDirectMemoryForward(int *ptr, int index, int size)
{
	if (index >= size) return;
	printf("%2d ", ptr[index]);
	printDirectMemoryForward(ptr, index + 1, size);
}

void printDirectMemoryBackward(int *ptr, int index)
{
	if (index < 0) return;
	printf("%2d ", ptr[index]);
	printDirectMemoryBackward(ptr, index - 1);
}

int main()
{
	// Выделение памяти для динамического массива
	int **arr = (int **)malloc(ROWS * sizeof(int *));
	void allocateMemory(int index)
	{
		if (index >= ROWS) return;
		arr[index] = (int *)malloc(COLS * sizeof(int));
		allocateMemory(index + 1);
	}
	allocateMemory(0);

	// Заполнение массива
	fillArray(arr, 0, 0, 1);

	// Вывод массива построчно (вперед)
	printf("Array forward:\n");
	printArrayForward(arr, 0, 0);

	// Вывод массива построчно (назад)
	printf("\nArray backward:\n");
	printArrayBackward(arr, ROWS - 1, COLS - 1);

	// Прямой доступ к памяти (вперед)
	printf("\nDirect memory access forward:\n");
	int *ptr = (int *)malloc(ROWS * COLS * sizeof(int));
	void fillDirectMemory(int row, int col)
	{
		if (row >= ROWS) return;
		if (col >= COLS)
		{
			fillDirectMemory(row + 1, 0);
			return;
		}
		ptr[row * COLS + col] = arr[row][col];
		fillDirectMemory(row, col + 1);
	}
	fillDirectMemory(0, 0);
	printDirectMemoryForward(ptr, 0, ROWS * COLS);

	// Прямой доступ к памяти (назад)
	printf("\nDirect memory access backward:\n");
	printDirectMemoryBackward(ptr, ROWS * COLS - 1);

	// Освобождение выделенной памяти
	void freeMemory(int index)
	{
		if (index >= ROWS) return;
		free(arr[index]);
		freeMemory(index + 1);
	}
	freeMemory(0);
	free(arr);
	free(ptr);

	return 0;
}
