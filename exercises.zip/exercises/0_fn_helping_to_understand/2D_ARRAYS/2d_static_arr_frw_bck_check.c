#include <stdio.h>

#define ROWS 2
#define COLS 4


int	main()
{
	int	arr[ROWS][COLS] = {
							{1, 2, 3, 4},
							{5, 6, 7, 8},
							// {9, 10, 11, 12}
							};
	int	*ptr = &arr[0][0];
	int i, j;

	printf("Array forward:\n");
	i = 0;
	while (i < ROWS)
	{
	j = 0;
		while (j < COLS)
		{
			printf("%5d", arr[i][j]);
			j++;
		}
	printf("\n");
	i++;
	}

	printf("Direct memory access forward:\n");
	i = 0;
	while (i < ROWS * COLS)
	{
		printf("%5d", *(ptr + i));
		i++;
	}
	printf("\n");

	printf("Array backward:\n");
	i = ROWS - 1;
		while (i >= 0)
		{
		j = COLS - 1;
			while (j >= 0)
			{
			printf("%5d", arr[i][j]);
			j--;
			}
		printf("\n");
		i--;
		}
		printf("\n");

	printf("Direct memory access backward:\n");
	i = ROWS * COLS -1;
	while (i >= 0)
		{
			printf("%5d", *(ptr + i));
			i--;
		}
	printf("\n");
	return (0);
}
