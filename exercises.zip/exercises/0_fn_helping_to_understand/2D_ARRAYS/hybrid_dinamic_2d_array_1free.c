#include <stdlib.h>

void	allocate_and_free(int N, int M)
{
// before it was: 
// int	**A;

int **A = (int **) malloc(N * sizeof(int*) + N * M * sizeof(int));
// before it was: 
//    A = (int**) malloc(N * sizeof(int*));
if (A == NULL)
	return; //handle error
int *start = (int*)((char*)A + N * sizeof(int*));
for (int i = 0; i < N; ++i)
	A[i] = start + i * M;
// before it was: 
// {
// 	A[i] = (int*) malloc(M * sizeof(int));
// 	if (A[i] == NULL)
// 		return; //handle error
// }
// Use the array. . .
// before it was first free(the raw): 
// for (int i = 0; i < N; i++) free(A[i]);
free(A);
}

int	main()
	{
		allocate_and_free(10, 10);
		return (0);
	}
