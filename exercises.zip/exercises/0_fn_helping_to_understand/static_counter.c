#include <stdio.h>

void counter()
{
	static int count = 0;  // Статическая переменная сохраняет значение между вызовами функции
	count++;
	printf("Count: %d\n", count);
}

int main()
{
	counter();  // Выведет "Count: 1"
	counter();  // Выведет "Count: 2"
	counter();  // Выведет "Count: 3"
	return 0;
}
