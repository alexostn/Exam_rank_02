#include <stdlib.h>

struct dinner
{
	int	x;
	int	y;
};

int	main()
{
struct	dinner *p;

p = (struct dinner *) malloc (sizeof(struct dinner));
if (p == NULL)
	{
	printf("there is not enough space for dinner");
	return (1);
	}
free (p);
return (0);
}