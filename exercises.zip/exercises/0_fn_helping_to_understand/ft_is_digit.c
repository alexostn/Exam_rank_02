#include <stdio.h>

int	ft_is_digit(int c)
{
	return (c >= '0' && c <= '9');
}

int	main(int ac, char *av[])
{
	if (ac == 2)
	{
		printf("%d", ft_is_digit(av[1][1]));
	}
	return (0);
}
