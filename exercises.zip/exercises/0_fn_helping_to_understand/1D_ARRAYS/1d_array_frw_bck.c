#include <stdio.h>

int main()
{
    int arr[] = {10, 20, 30, 40, 50};
    int *ptr = arr;
    
    // Двигаемся вперед
    for (int i = 0; i < 5; i++)
    {
        printf("Forward: %d\n", *(ptr + i));
    }
    
    // Двигаемся назад
    for (int i = 4; i >= 0; i--)
    {
        printf("Backward: %d\n", *(ptr + i));
    }

    return 0;
}
