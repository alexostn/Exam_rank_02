#include <stdio.h>

int	main ()
{
	int i = 0;
	int arr[] = {10, 20, 30};
	// int *ptr = arr;

	int len= (sizeof arr / sizeof arr[0]);

	while (i < (len))
	{
		
		printf("%3d", arr[i]);
		i++;
	}
	i--;
	// printf("  I :%3d", i);
	while (i >= 0)
	{
		// printf("  I :%3d", i);
		printf("%3d", arr[i]);
		i--;
	}
	return (0);
}