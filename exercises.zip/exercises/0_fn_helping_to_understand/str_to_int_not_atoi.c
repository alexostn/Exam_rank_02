#include <stdio.h>
#include <string.h>

int str_to_int(char *str, int length)
{
    if (*str == '\0')
        return 0;
    else
        return (str[0] - '0') * length + str_to_int(str + 1, length / 10);
}

int calculate_length(char *str)
{
    if (*str == '\0')
        return 1;
    else
        return 10 * calculate_length(str + 1);
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Please provide a number as a command line argument.\n");
        return 1;
    }

    int length = calculate_length(argv[1]) / 10;
    int num = str_to_int(argv[1], length);
    printf("The converted number is: %d\n", num);

    return 0;
}