int ft_atoi_c (const char *str)
{
	int	sign;
	int	result;
	
	result = 0;
	sign = 1;
		while (*str == 32 || *str >= 9 && *str <= 13)
			str++;
	if (*str == '-')
		sign = -1;
	if (*str == '-' || *str == '+')
		str++;
	while (*str >= '0' && *str <= '9')
		{
		result = result * 10 + (*str - '0');
		str++;
		}
	return (result * sign);
}

#include <stdio.h>
int	main (int ac, char *av[])
{
	if (ac == 2)
		printf("%d", ft_atoi_c(av[1]));
	return (0);
}
