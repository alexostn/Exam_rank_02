#include <stdlib.h> // для malloc

int	*ft_range(int start, int end)
{
	int len;
	int *array;
	int i;

	// Определяем размер массива (количество чисел от start до end)
	len = (start <= end) ? (end - start + 1) : (start - end + 1);

// if (start <= end) {
//     len = end - start + 1;
// } else {
//     len = start - end + 1;
// }
	// Выделяем память под массив
	array = (int *)malloc(len * sizeof(int));
	if (array == NULL)
		return (NULL); // Если malloc вернул NULL, возвращаем NULL

	// Заполняем массив
	i = 0;
	if (start <= end) // Если числа идут в порядке возрастания
	{
		while (start <= end)
		{
			array[i] = start;
			start++;
			i++;
		}
	}
	else // Если числа идут в порядке убывания
	{
		while (start >= end)
		{
			array[i] = start;
			start--;
			i++;
		}
	}

	// Возвращаем указатель на первый элемент массива
	return (array);
}

#include <stdio.h>

int main(int ac, char **av)
{
    if (ac == 3)
    {
        int *result;
        int start = atoi(av[1]);
        int end = atoi(av[2]);
        int len = abs(end - start) + 1;
        int i;

        result = ft_range(start, end);
        for (i = 0; i < len; i++)
        {
            printf("%d ", result[i]);
            // if (i < len - 1)//для запятых
            // {
            //     printf(", ");
            // }
        }
        printf("\n");
    }
    return (0);
}
