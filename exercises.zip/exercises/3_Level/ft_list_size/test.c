#include "ft_list.h"
#include "ft_list_size.c"
#include <stdio.h>
#include <stdlib.h>

int main() {
    t_list *head = NULL;
    t_list *temp1 = NULL;
    t_list *temp2 = NULL;
    t_list *temp3 = NULL;

    // Создаем список из трех элементов
    temp1 = malloc(sizeof(t_list));
    temp2 = malloc(sizeof(t_list));
    temp3 = malloc(sizeof(t_list));

    temp1->next = temp2;
    temp2->next = temp3;
    temp3->next = NULL;
    head = temp1;

    // Выводим размер списка
    printf("Size of the list: %d\n", ft_list_size(head));

    // Освобождаем память
    while (head) {
        t_list *temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}