#include <stdio.h>
#include <stdlib.h>

// Определение структуры узла списка
typedef struct s_list
{
	int data;               // Данные узла
	struct s_list *next;    // Указатель на следующий узел
} t_list;

// Функция для подсчета узлов в связанном списке
int ft_list_size(t_list *begin_list)
{
	int i = 0;

	while (begin_list)
	{
		i++;
		begin_list = begin_list->next;
	}
	return (i);
}

// Функция для создания нового узла
t_list *create_node(int data)
{
	t_list *new_node = malloc(sizeof(t_list));
	if (new_node)
	{
		new_node->data = data;
		new_node->next = NULL;
	}
	return new_node;
}

// Главная функция
int main()
{
	// Создаем связанные узлы
	t_list *head = create_node(1); // Первый узел
	head->next = create_node(2);    // Второй узел
	head->next->next = create_node(3); // Третий узел

	// Подсчитываем количество узлов
	int size = ft_list_size(head);
	printf("Size of the list: %d\n", size); // Вывод: Size of the list: 3

	// Освобождаем выделенную память
	t_list *temp;
	while (head)
	{
		temp = head;
		head = head->next;
		free(temp);
	}

	return 0;
}
