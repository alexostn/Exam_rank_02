#include <stdio.h>
#include <stdlib.h>

typedef struct    s_list
{
    struct s_list	*next;
    int				data;//void	*data;
}                 t_list;

int	ft_list_size(t_list *begin_list)
{
	int	i = 0;

	while (begin_list)
	{
		i++;
		begin_list = begin_list->next;
	}
	return (i);
}

t_list *create_node(int	data)
{
	t_list	*new_node = malloc(sizeof(t_list));
	if (new_node)
	{
		new_node->data = data;
		new_node->next = NULL;
	}
	return (new_node);
}

int	main()
{
	t_list	*head = create_node(1);
	t_list	head->next = create_node(2);
	t_list	head->next->next = create_node(3);

	int size = ft_list_size(head);
	printf("sizeof the list is: %d\n:", size);

	t_list	*temp;
	while (head)
	{
		temp = head;
		head = head->next;
		free(temp);
	}
	return (0);
}
