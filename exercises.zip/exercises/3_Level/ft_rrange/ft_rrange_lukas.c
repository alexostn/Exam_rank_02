#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
int ft_abs(int nbr)
{
 if(nbr < 0)
  return(-nbr);
 return(nbr);
}

int     *ft_range(int start, int end)
{
 int *tmp = 0;
 int len = 0;
 int i = 0;
 if(start < end)
 {
  len = ft_abs(end - start) + 1;
  //printf("%i\n", len);
  tmp = (int *)malloc(sizeof(int) * len);
 }
 else
 {
  len = ft_abs(start - end) + 1; 
  //printf("%i\n", len);
  tmp = (int *)malloc(sizeof(int) * len);
 }
 if(tmp == NULL)
   return (0);
 tmp[i] = start;
 if(start < end)
 {
  while(start <= end)
  {
   tmp[i] = start;
   i++;
   start++;
  }
 }
 else
 {
  while(start >= end)
  {
   tmp[i] = start;
   i++;
   start--;
  }
 }
 return(tmp);
}

/*
#include <stdio.h>
int main(void)
{
 int *tab;
 int i = 0;
 int start = 3;
 int end = 8;
 int len = 0;

 tab = ft_range(start, end);
 len = ft_abs(end - start) + 1;
 while (i < len)
 {
  printf(" [%i] ", tab[i]);
  i++;
 }
 printf("\n");
}*/