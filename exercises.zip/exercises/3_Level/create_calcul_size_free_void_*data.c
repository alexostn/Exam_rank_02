#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Определение структуры узла списка
typedef struct s_list
{
	void *data;               // Указатель на данные узла (любой тип)
	struct s_list *next;      // Указатель на следующий узел
} t_list;

// Функция для подсчета узлов в связанном списке
int ft_list_size(t_list *begin_list)
{
	int i = 0;

	while (begin_list)
	{
		i++;
		begin_list = begin_list->next;
	}
	return (i);
}

// Функция для создания нового узла
t_list *create_node(void *data)
{
	t_list *new_node = malloc(sizeof(t_list));
	if (new_node)
	{
		new_node->data = data;
		new_node->next = NULL;
	}
	return new_node;
}

// Главная функция
int main()
{
	// Создаем данные для узлов (в данном случае это строки)
	char *data1 = strdup("Node 1");
	char *data2 = strdup("Node 2");
	char *data3 = strdup("Node 3");

	// Создаем связанные узлы с указателями на данные
	t_list *head = create_node(data1); // Первый узел
	head->next = create_node(data2);    // Второй узел
	head->next->next = create_node(data3); // Третий узел

	// Подсчитываем количество узлов
	int size = ft_list_size(head);
	printf("Size of the list: %d\n", size); // Вывод: Size of the list: 3

	// Выводим данные каждого узла
	t_list *current = head;
	while (current)
	{
		printf("Data: %s\n", (char *)current->data); // Приведение указателя к char *
		current = current->next;
	}

	// Освобождаем выделенную память
	t_list *temp;
	while (head)
	{
		temp = head;
		head = head->next;
		free(temp->data); // Освобождаем память, занятую данными (строкой)
		free(temp);       // Освобождаем память, занятую узлом
	}

	return 0;
}
