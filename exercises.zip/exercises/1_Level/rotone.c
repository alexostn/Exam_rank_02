#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void rotone(char *s)
{
	while (*s)
	{
		if (*s == 'Z' || *s == 'z')
			{
			*s = *s - 25;
			write(1, s, 1);// прямой тип записи
			}
		
		else if ((*s >= 'a' && *s <= 'y') || (*s >= 'A' && *s <= 'Y'))
			ft_putchar(*s + 1);
		else
			ft_putchar(*s);
		++s;
	}
	write(1, "\n", 1);
}

int main (int ac, char *av[])
{
	if (ac == 2)
		rotone(av[1]);
	write(1, "\n", 1);
	return (0);
}