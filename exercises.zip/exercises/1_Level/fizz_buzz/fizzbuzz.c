#include <unistd.h>


int	ft_putnbr(int i)
{
	char	c;
	// if (i < 0)
	// {
	// 	write (1, "-", 1);
	// 	i = -i;
	// }
	if (i >= 100)
		return (1);
	if (i >= 10)
		ft_putnbr(i / 10);
	c = (i % 10) + '0';
	write (1, &c, 1);
	return (0);
}

void	main()
{
	int	n = 1;

	while (n < 100)
	{
		if((n % 3) == 0 && (n % 5) == 0)
		{
			write (1, "fizzbuzz\n", 9);
			n++;
		}
		if ((n % 5) == 0)
		{
			write (1, "buzz\n", 5);
			n++;
		}
		if ((n % 3) == 0)
		{
			write (1, "fizz\n", 5);
			n++;
		}
				if ((n % 5) == 0)
		{
			write (1, "buzz\n", 5);
			n++;
		}
		ft_putnbr(n);
		write (1, "\n", 1);
		n++;
	}
}