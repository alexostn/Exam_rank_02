#include <unistd.h>

char	*rev_print_prove(char	*str)
{
	int	i = 0;

	while (str[i] != '\0')
		i++;
	while (--i >= 0)
		write (1, &str[i], 1);
	write (1, "\n", 1);
	return (str);
}

int main(void)
{
  rev_print_prove("Hello world");
  write (1, "\n", 1);
  rev_print_prove("tnirp esreveR");
  write (1, "\n", 1);
  rev_print_prove("");
  write (1, "\n", 1);
}