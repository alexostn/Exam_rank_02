#include <unistd.h>

int	ft_strlen(const char *s)
{
	int	len = 0;

	while (*s)
	{
		s++;
		len++;
	}
	return (len);
}

char *rev_print_rdv(char *str)
{
	int	l = ft_strlen(str) - 1;

	while (l >= 0)
	{
		write (1, &str[l], 1);
		l--;
	}
	write (1, "\n", 1);
return (str);
}

int main(void)
{
  rev_print_rdv("Hello world");
  write (1, "\n", 1);
  rev_print_rdv("tnirp esreveR");
  write (1, "\n", 1);
  rev_print_rdv("");
  write (1, "\n", 1);
}